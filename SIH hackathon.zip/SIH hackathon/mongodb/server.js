// server.js
const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname)); // serve index.html

// ✅ Connect to MongoDB
mongoose.connect("mongodb+srv://aburvaasenthilkumarias:abusen1402@03-task-manager.mr3a6jw.mongodb.net/?retryWrites=true&w=majority&appName=03-task-manager", {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ MongoDB Connected"))
.catch(err => console.log(err));

// ✅ Schema & Model
const UserSchema = new mongoose.Schema({
  name: String,
  email: String
});
const User = mongoose.model("User", UserSchema);

// ✅ CREATE
app.post("/add", async (req, res) => {
  const user = new User({ name: req.body.name, email: req.body.email });
  await user.save();
  res.redirect("/");
});

// ✅ READ (for frontend display)
app.get("/users", async (req, res) => {
  const users = await User.find();
  res.json(users);
});

// ✅ UPDATE
app.post("/update", async (req, res) => {
  await User.findByIdAndUpdate(req.body.id, { name: req.body.name });
  res.redirect("/");
});

// ✅ DELETE
app.post("/delete", async (req, res) => {
  await User.findByIdAndDelete(req.body.id);
  res.redirect("/");
});

app.listen(3000, () => console.log("🚀 Server running on http://localhost:3000"));
