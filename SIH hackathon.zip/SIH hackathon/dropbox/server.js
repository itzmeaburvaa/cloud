const express = require("express");
const multer = require("multer");
const Dropbox = require("dropbox").Dropbox;
const fs = require("fs");
const fetch = require("node-fetch");

const app = express();
const upload = multer({ dest: "uploads/" });

const ACCESS_TOKEN = "YOUR_ACCESS_TOKEN_HERE"; // replace with your Dropbox token
const dbx = new Dropbox({ accessToken: ACCESS_TOKEN, fetch: fetch });

app.use(express.static("."));

app.post("/upload", upload.single("file"), async (req, res) => {
  const file = req.file;
  if (!file) return res.send("No file uploaded!");

  const contents = fs.readFileSync(file.path);
  try {
    await dbx.filesUpload({ path: "/" + file.originalname, contents, mode: "overwrite" });
    fs.unlinkSync(file.path); // delete temp file
    res.send(`✅ ${file.originalname} uploaded successfully!`);
  } catch (err) {
    res.send("❌ Upload failed!");
    console.error(err);
  }
});

app.listen(3000, () => console.log("Server running at http://localhost:3000"));
