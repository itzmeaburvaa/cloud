from flask import Flask, render_template, request, redirect
import dropbox
import os

app = Flask(__name__)

# Replace with your actual Dropbox access token
ACCESS_TOKEN = 'sl.u.AGC7tYon9WR1S8nuwPNGUT52JyHobYSMJEyiCiLWypcbmeAVcYAVJu0tmEgDsqMGTobCft8BjUq2NSa3W6AqivMEgbvkamYFaL9_n1omU0ADI4jcrAK0S6cUzbEzbrEoMNnTSKXxrUfWJyUcFjHfIIDfkpwRPxln0o2g9XG33MbzqJrAkR9xO3Q6KKwDGIZZh3x17-XPOlNsYrqdph3mNKafOYTxH8B6mcyHlsZ03Lz-UTNeOcOxQAJ3YpBpdsf18NBWaueoZch7_kzy82Fode-nM53l6IXOtxqUu5cSiSSsBrh2gPNAOMop4f1DpGpb7WjbXOy523tXQKezetouGS0dDvpU8IUlIBEcV1dTlGvmAZoxGN-ozi67zH_2YU_UQbfdvY1uBMTdZxSHWKqrKXquFtgBXzTSj0CXRdfXGvZ5cNDPM0rlVmQW08QcDgPPk_sI-xVVWi545Eam1LKKAsauLTEHH_JYfqzO_M5v04nWVuFjif6zf7ppLHEH27CMpuZaHv5EnJ4e7jFIBv3Wk0QNLF-zk-PabOfTwgSDcc2qhHmnM4eyEgzPJAi6Kbhkx1-R_a1_IIDjpUbxuHi8IdhTTb7vcO5jWqElVj9KPMbqnzDvc8u_DaKV6jXNdYLrfJXkHmERv7AVYwl5ou2hjqI32ypw7ll2pMthPrxkvV9Fmht2vIky5ZeYBl6Qe1zI-cXEl_cKMqcuN4fo3dLxXGhSVSJgUsItUl4r9vXAVHpuxRfQ_mWizI8-aCi8y7jd3yk-o1Qw94nK_RfNqHWsxhY-je0c9JEqy4yqU2mRvpGsPpPljLw2-P2t4EfxbDh0ZYGFJK1hNREa_qi5onPVW6FeVjSRyfDvvPrFaFQxMQ6kmuuzcTcmW3uoTw7TjERtDBVRMTFwCLJUDaimH6ZkzVB8XksPDRM21cZH8uLxOpiE6nZqfe8RYBFohjhvfRMOKrNze5Ra3v1p1t2EckD7H_8s9v4w7bzV7UmSsQT9azlW4f5uCNY9U629d_Acg7gOg1N1VajeHnBkT8wExWxvp2VuHobAZsKU8j5f5ySEMBO4fQ89pJsmN5-0Ck9rNOG1Jtz-K4MGgwOVt56bSzJwcP8PkClrLqJ-Y3bfXSJOmJCdV_JSiq6DZGvC4qAotxbsJQAoMZLUrpi9VXb2fJAUgD9ZyoPEyXc7qVdUuhsi1Vh-y51YMwXnKGbz4gXpQYBfOG-G7yirKg6RCLynHR0B9VBzttE1EgiMhk1jBcHr__AoeFLUuGvtf91d2tXT0lE6p_nniGJGOnPXx8wAUeVfNZWiQrQgnlgFPo7e8UZERbapo2mVIiH301bSN_QayFqvHNhd8BT1KEaxspMxayiTQf3p29XeX28D00OiUKMfj-5O9M1JNZW64qtJORJC5wpX0phZ-SiPnyqQ0P6er4whn9pbnAJHpLBE5H8JWFLmSsIHfQ'
dbx = dropbox.Dropbox(ACCESS_TOKEN)

@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return "No file uploaded", 400

    file = request.files['file']
    filename = file.filename

    if filename == '':
        return "Empty filename", 400

    # Upload file to Dropbox
    try:
        dbx.files_upload(file.read(), '/' + filename, mode=dropbox.files.WriteMode.overwrite)
    except Exception as e:
        return f"Error uploading to Dropbox: {e}", 500

    return redirect('/success')

@app.route('/success')
def success():
    return "✅ File uploaded to Dropbox successfully!"

if __name__ == '__main__':
    app.run(debug=True)
